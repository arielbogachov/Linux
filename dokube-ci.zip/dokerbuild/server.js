const express = require('express');
const path = require('path');

const apiRoutes = require('./src/routes/api');
const webhookRoutes = require('./src/routes/webhook');
const { initScheduler } = require('./src/scheduler');

const app = express();
const PORT = process.env.PORT || 8080;

app.use(express.json());
app.use('/api', apiRoutes);
app.use('/webhook', webhookRoutes);
app.use(express.static(path.join(__dirname, 'public')));

app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

initScheduler();

app.listen(PORT, () => {
  console.log(`\n  DoKube CI running at http://localhost:${PORT}\n`);
});
