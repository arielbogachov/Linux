# DoKube CI

A small, Jenkins-style automation server for pipelines that span **Docker** and **Kubernetes** — build an image, push it, convert a Compose file to K8s manifests, and deploy — all as one job, with a web dashboard, a CLI, run history, and three trigger types (manual, cron, webhook).

## Features

- **Pipeline steps**: `dockerBuild`, `dockerPush`, `composeConvert` (Compose → K8s YAML), `k8sDeploy`, `shell`
- **Triggers**: manual (click Run), cron schedule, or webhook (`POST /webhook/:jobName`)
- **Persistence**: SQLite-backed job definitions, run history, and step-by-step logs
- **Web dashboard**: create pipelines, watch live logs, browse run history
- **CLI**: script the same server from your terminal

## Requirements

- Node.js 18+
- Docker daemon running locally (for `dockerBuild` / `dockerPush` steps) — the server talks to it via the Docker socket, same as the `docker` CLI
- A kubeconfig at `~/.kube/config` (or in-cluster config) for `k8sDeploy` steps

## Setup

```bash
npm install
npm start
```

The dashboard runs at **http://localhost:8080**.

## Using the CLI

The CLI talks to the running server over HTTP (set `DOKUBE_URL` if it's not on localhost:8080).

```bash
# Link the CLI (optional, for a global `dokube` command)
npm link

# Create a job from a JSON definition
dokube create examples/build-deploy.json

# List jobs
dokube list

# Trigger a run
dokube run build-and-deploy-web

# Follow logs live
dokube logs <runId> --follow

# List recent runs
dokube runs
```

## Job definition format

```json
{
  "name": "build-and-deploy-web",
  "description": "Build, push, convert, deploy",
  "trigger_type": "webhook",           // "manual" | "cron" | "webhook"
  "trigger_config": { "secret": "change-me" },  // or { "schedule": "*/15 * * * *" } for cron
  "steps": [
    { "type": "dockerBuild", "context": ".", "dockerfile": "Dockerfile", "tag": "myapp/web:latest" },
    { "type": "dockerPush", "tag": "myapp/web:latest" },
    { "type": "composeConvert", "composeFile": "docker-compose.yml", "outputDir": "./k8s" },
    { "type": "k8sDeploy", "namespace": "staging" }
  ]
}
```

Steps run in order; later steps can rely on earlier ones (e.g. `k8sDeploy` will use the manifests written by a preceding `composeConvert` step automatically if `manifestDir`/`manifestPath` is omitted).

## Triggering via webhook

Point your git host's webhook (or `curl`) at:

```
POST http://your-server:8080/webhook/<job-name>?secret=<secret>
```

## Project layout

```
server.js              Express entry point
src/db.js               SQLite schema + connection
src/scheduler.js        node-cron wiring for cron-triggered jobs
src/routes/api.js       REST API: jobs, runs, logs
src/routes/webhook.js   Webhook trigger endpoint
src/jobs/executor.js    Runs a job's steps in order, streams logs to SQLite
src/jobs/steps/*.js     One module per step type
bin/cli.js              CLI (dokube ...)
public/                 Dashboard (vanilla HTML/CSS/JS, no build step)
examples/                Example job JSON for the CLI
```

## Notes

- This was built to run against a **real** Docker daemon and Kubernetes cluster — the step modules use `dockerode` and `@kubernetes/client-node`, the same libraries production tooling uses. There's no simulation layer, so nothing will execute successfully until it can reach an actual Docker socket / kubeconfig.
- The Compose→K8s converter covers the common subset (image, ports, environment, command, `deploy.replicas`) — not every Compose feature. For a full-fidelity conversion, `kompose convert` is a good complement.
